
public class ListNode {
		String name;
		String email;
		String password;
		String status;
}